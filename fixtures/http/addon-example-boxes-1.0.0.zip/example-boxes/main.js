// Gives every game the same box, from the fixture host.
export function lookup(q) {
  if (!q.wanted.includes('thumbnail')) return null;
  return { media: [{ kind: 'thumbnail', url: 'https://boxes.example.com/' + encodeURIComponent(q.stem) + '.png' }] };
}

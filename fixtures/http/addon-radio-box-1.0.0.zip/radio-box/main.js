const STATIONS = [
  { name: 'Chip FM', url: 'https://radio.example.com/chip' },
  { name: 'Arcade Lounge', url: 'https://radio.example.com/lounge' }
];

function all() {
  const own = forma.settings.get('station');
  return own ? [...STATIONS, { name: 'Your station', url: own }] : STATIONS;
}

export function stations() {
  return all();
}

export function page({ path }) {
  if (path[0] === 'about') {
    return { title: 'About', rows: [{ label: 'A test add-on' }] };
  }
  return {
    title: 'Radio box',
    rows: [
      ...all().map((s, i) => ({
        heading: i === 0 ? 'Stations' : undefined,
        label: s.name,
        detail: s.url
      })),
      { heading: 'Tuner', label: 'Tune', action: 'tune', ask: { title: 'Frequency' } },
      { label: 'About', open: ['about'] }
    ]
  };
}

export function action({ action, input }) {
  if (action === 'tune') return { notify: forma.system.run('tune', [String(input)]) };
  return { notify: `nothing called ${action}` };
}

#!/bin/sh
echo "tuned to $1"

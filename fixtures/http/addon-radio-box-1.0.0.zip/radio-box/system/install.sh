#!/bin/sh
echo installed
